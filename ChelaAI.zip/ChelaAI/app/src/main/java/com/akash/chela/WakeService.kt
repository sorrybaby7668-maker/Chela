package com.akash.chela

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground (microphone) service that listens for "Hello CHELA", greets, then takes one command
 * (or follows a multi-step flow such as a call/WhatsApp confirmation) and goes back to waiting.
 */
class WakeService : Service(), Listener.Cb {
    companion object {
        const val ACTION_STOP = "chela.stop"
        const val ACTION_PAUSE = "chela.pause"
        const val ACTION_RESUME = "chela.resume"
        private const val CH = "chela_service"
        @Volatile var running = false
    }

    private val h = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var listener: Listener
    private lateinit var speaker: Speaker
    private var command = false
    private var busy = false
    private var paused = false

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        listener = Listener(this, this)
        speaker = Speaker(this)
        speaker.finished = { if (!paused) { if (command) listen() else wake() } }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { Chela.store.wake = false; stopSelf(); return START_NOT_STICKY }
            ACTION_PAUSE -> { paused = true; listener.stop(); speaker.stop(); return START_STICKY }
            ACTION_RESUME -> { paused = false; wake(); return START_STICKY }
        }
        try {
            ServiceCompat.startForeground(this, 1, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) { stopSelf(); return START_NOT_STICKY }
        wake()
        return START_STICKY
    }

    private fun lang() = if (Chela.store.hindi) "hi-IN" else "en-IN"

    private fun wake() {
        command = false; busy = false
        Chela.orb.value = OrbState.IDLE
        h.postDelayed({ if (!paused) listener.start(lang()) }, 500)
    }

    private fun listen() {
        busy = false
        Chela.orb.value = OrbState.LISTENING
        h.postDelayed({ if (!paused) listener.start(lang()) }, 200)
    }

    private fun say(text: String) {
        Chela.orb.value = OrbState.SPEAKING
        speaker.enabled = Chela.store.voiceOn
        speaker.speak(text)
    }

    private fun greet() {
        busy = true; command = true
        listener.stop()
        Chela.store.addMsg(Msg("assistant", Wake.GREETING))
        say(Wake.GREETING)
    }

    private fun respond(text: String) {
        busy = true
        Chela.orb.value = OrbState.THINKING
        scope.launch {
            val r = Chela.assistant.converse(text)
            command = Chela.assistant.pending != null
            say(r)
        }
    }

    override fun partial(t: String) {
        if (!command && !busy && Wake.isWake(t)) greet()
    }

    override fun result(t: String) {
        if (paused || busy) return
        if (!command) {
            if (Wake.isWake(t)) { val rest = Wake.rest(t); if (rest.length > 2) respond(rest) else greet() } else wake()
        } else {
            if (t.isBlank()) wake() else respond(t)
        }
    }

    override fun error(code: Int) {
        if (paused || busy) return
        if (code == -1 || code == 9) { stopSelf(); return } // no recognizer / no mic permission
        wake()
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "CHELA AI listening", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1, Intent(this, WakeService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("CHELA AI active")
            .setContentText("Say “Hello CHELA” — microphone in use")
            .setContentIntent(open).addAction(0, "Stop", stop).setOngoing(true).build()
    }

    override fun onDestroy() {
        running = false
        h.removeCallbacksAndMessages(null)
        listener.stop(); speaker.shutdown(); scope.cancel()
        Chela.orb.value = OrbState.IDLE
        super.onDestroy()
    }
}
