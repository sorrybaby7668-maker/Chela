package com.akash.chela

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Text-to-speech. Uses a Hindi female Google voice when installed, switching to en-IN for English text. */
class Speaker(ctx: Context) {
    private val main = Handler(Looper.getMainLooper())
    private var tts: TextToSpeech? = null
    private var ready = false
    var enabled = true
    var finished: (() -> Unit)? = null

    init {
        tts = TextToSpeech(ctx) { status ->
            ready = status == TextToSpeech.SUCCESS
            if (ready) tts?.apply {
                setPitch(1.12f)
                setSpeechRate(0.95f)
                setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) {}
                    override fun onDone(id: String?) { main.post { finished?.invoke() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { finished?.invoke() } }
                })
            }
        }
    }

    fun speak(raw: String) {
        val t = tts
        if (!enabled || !ready || t == null) { main.post { finished?.invoke() }; return }
        val text = raw.replace(Regex("[*#_`]"), "").take(3500)
        val hi = text.any { it in '\u0900'..'\u097F' }
        t.setLanguage(Locale(if (hi) "hi" else "en", "IN"))
        val prefer = if (hi) listOf("hi-in-x-hia", "hi-in-x-hic") else listOf("en-in-x-ena", "en-in-x-enc")
        t.voices?.firstOrNull { v -> prefer.any { v.name.startsWith(it) } }?.let { t.voice = it }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "chela")
    }

    fun stop() { tts?.stop() }
    fun shutdown() { tts?.stop(); tts?.shutdown() }
}

/** Speech recognition (Hindi hi-IN / English en-IN). Must be used from the main thread. */
class Listener(private val ctx: Context, private val cb: Cb) {
    interface Cb {
        fun partial(t: String) {}
        fun result(t: String)
        fun error(code: Int)
    }

    private var rec: SpeechRecognizer? = null

    fun start(lang: String) {
        stop()
        if (!SpeechRecognizer.isRecognitionAvailable(ctx)) { cb.error(-1); return }
        rec = SpeechRecognizer.createSpeechRecognizer(ctx).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(b: Bundle?) {
                    cb.result(b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty())
                }
                override fun onPartialResults(b: Bundle?) {
                    b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { cb.partial(it) }
                }
                override fun onError(e: Int) { cb.error(e) }
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(v: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                .putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
                .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1))
        }
    }

    fun stop() { rec?.let { it.cancel(); it.destroy() }; rec = null }
}
