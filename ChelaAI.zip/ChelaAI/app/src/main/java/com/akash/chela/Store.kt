package com.akash.chela

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class Msg(val role: String, val text: String, val ts: Long = System.currentTimeMillis())
data class Todo(val text: String, val done: Boolean = false)

/** Local storage: settings, chat history, notes, to-dos and "remembered" preferences. */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("chela_store", Context.MODE_PRIVATE)

    /** Bumps on every change so Compose screens (and the wake service) stay in sync. */
    val rev = MutableStateFlow(0)
    private fun bump() { rev.value = rev.value + 1 }

    var voiceOn: Boolean
        get() = p.getBoolean("voice", true)
        set(v) { p.edit().putBoolean("voice", v).apply() }
    var hindi: Boolean
        get() = p.getBoolean("hindi", true)
        set(v) { p.edit().putBoolean("hindi", v).apply() }
    var wake: Boolean
        get() = p.getBoolean("wake", false)
        set(v) { p.edit().putBoolean("wake", v).apply() }
    var city: String
        get() = p.getString("city", "Delhi") ?: "Delhi"
        set(v) { p.edit().putString("city", v).apply() }

    private fun arr(k: String): JSONArray =
        try { JSONArray(p.getString(k, "[]")) } catch (e: Exception) { JSONArray() }

    private fun save(k: String, a: JSONArray) { p.edit().putString(k, a.toString()).apply(); bump() }
    private fun strings(k: String): List<String> { val a = arr(k); return (0 until a.length()).map { a.getString(it) } }
    private fun saveStrings(k: String, l: List<String>) = save(k, JSONArray(l))

    // ---- chat history (last 200) ----
    fun history(): List<Msg> {
        val a = arr("hist")
        return (0 until a.length()).map { val o = a.getJSONObject(it); Msg(o.getString("r"), o.getString("t"), o.getLong("ts")) }
    }

    @Synchronized
    fun addMsg(m: Msg) {
        val a = arr("hist")
        a.put(JSONObject().put("r", m.role).put("t", m.text).put("ts", m.ts))
        val t = JSONArray()
        for (i in maxOf(0, a.length() - 200) until a.length()) t.put(a.get(i))
        save("hist", t)
    }

    fun clearHistory() = save("hist", JSONArray())

    // ---- notes ----
    fun notes() = strings("notes")
    fun addNote(s: String) = saveStrings("notes", notes() + s)
    fun deleteNote(i: Int) = saveStrings("notes", notes().filterIndexed { x, _ -> x != i })

    // ---- remembered preferences ----
    fun memory() = strings("memory")
    fun remember(s: String) = saveStrings("memory", (memory() + s).takeLast(30))
    fun clearMemory() = saveStrings("memory", emptyList())

    // ---- to-do ----
    fun todos(): List<Todo> {
        val a = arr("todos")
        return (0 until a.length()).map { val o = a.getJSONObject(it); Todo(o.getString("t"), o.getBoolean("d")) }
    }
    private fun saveTodos(l: List<Todo>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("t", it.text).put("d", it.done)) }; save("todos", a)
    }
    fun addTodo(s: String) = saveTodos(todos() + Todo(s))
    fun toggleTodo(i: Int) = saveTodos(todos().mapIndexed { x, t -> if (x == i) t.copy(done = !t.done) else t })
    fun deleteTodo(i: Int) = saveTodos(todos().filterIndexed { x, _ -> x != i })
}
