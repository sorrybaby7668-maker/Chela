package com.akash.chela

import android.app.Application
import android.content.Intent
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

/** Activity-side voice conversation controller (mic button, conversation mode, typed chat). */
class ChelaViewModel(private val app: Application) : AndroidViewModel(app), Listener.Cb {
    val store get() = Chela.store
    val partial = mutableStateOf("")
    val conv = mutableStateOf(false)
    val weather = mutableStateOf("…")
    val voiceOn = mutableStateOf(Chela.store.voiceOn)

    private val speaker = Speaker(app).also { it.finished = { onSpoken() } }
    private val listener = Listener(app, this)
    private var lastVoice = false

    init { refreshWeather() }

    fun refreshWeather() = viewModelScope.launch { weather.value = "…"; weather.value = Net.weather(store.city) }

    fun setVoice(on: Boolean) { store.voiceOn = on; voiceOn.value = on; if (!on) speaker.stop() }

    private fun wakeCmd(action: String) {
        if (store.wake && WakeService.running) app.startService(Intent(app, WakeService::class.java).setAction(action))
    }

    fun mic() {
        if (Chela.orb.value == OrbState.LISTENING) { listener.stop(); idle(); return }
        speaker.stop(); startListen()
    }

    private fun startListen() {
        wakeCmd(WakeService.ACTION_PAUSE)
        Chela.orb.value = OrbState.LISTENING
        listener.start(if (store.hindi) "hi-IN" else "en-IN")
    }

    override fun partial(t: String) { partial.value = t }

    override fun result(t: String) {
        partial.value = ""
        if (t.isBlank()) { conv.value = false; idle() } else send(t, voice = true)
    }

    override fun error(code: Int) { partial.value = ""; conv.value = false; idle() }

    fun send(text: String, voice: Boolean = false) {
        lastVoice = voice
        wakeCmd(WakeService.ACTION_PAUSE)
        viewModelScope.launch {
            Chela.orb.value = OrbState.THINKING
            val reply = Chela.assistant.converse(text)
            Chela.orb.value = OrbState.SPEAKING
            speaker.enabled = store.voiceOn
            speaker.speak(reply)
        }
    }

    private fun onSpoken() {
        if (conv.value || (lastVoice && Chela.assistant.pending != null)) startListen() else idle()
    }

    private fun idle() { Chela.orb.value = OrbState.IDLE; wakeCmd(WakeService.ACTION_RESUME) }

    override fun onCleared() {
        listener.stop(); speaker.shutdown()
        Chela.orb.value = OrbState.IDLE
        wakeCmd(WakeService.ACTION_RESUME)
    }
}
