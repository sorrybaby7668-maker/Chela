package com.akash.chela

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.provider.AlarmClock
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.net.URLEncoder

/** Builds the Intents for phone control. Nothing here sends a message or places a call by itself. */
object Actions {
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun web(url: String) = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    private fun app(c: Context, pkg: String, fallback: Intent) =
        c.packageManager.getLaunchIntentForPackage(pkg) ?: fallback

    fun youtube(c: Context, q: String?) =
        if (q.isNullOrBlank()) app(c, "com.google.android.youtube", web("https://www.youtube.com"))
        else web("https://www.youtube.com/results?search_query=" + enc(q))

    fun whatsapp(c: Context) = app(c, "com.whatsapp", web("market://details?id=com.whatsapp"))
    fun chrome(c: Context) = app(c, "com.android.chrome", web("https://www.google.com"))
    fun camera() = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)
    fun calculator(): Intent = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_CALCULATOR)
    fun settings() = Intent(Settings.ACTION_SETTINGS)
    fun google(q: String) = web("https://www.google.com/search?q=" + enc(q))

    /** Opens WhatsApp chat with the text pre-filled. The user must press Send themselves. */
    fun waMessage(number: String, text: String): Intent {
        var d = number.filter { it.isDigit() }
        if (d.length == 10) d = "91$d"
        return web("https://wa.me/$d?text=" + enc(text)).setPackage("com.whatsapp")
    }

    fun call(number: String) = Intent(Intent.ACTION_CALL, Uri.parse("tel:" + Uri.encode(number)))
    fun dial(number: String) = Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(number)))

    fun alarm(h: Int, m: Int, label: String) = Intent(AlarmClock.ACTION_SET_ALARM)
        .putExtra(AlarmClock.EXTRA_HOUR, h).putExtra(AlarmClock.EXTRA_MINUTES, m)
        .putExtra(AlarmClock.EXTRA_MESSAGE, label).putExtra(AlarmClock.EXTRA_SKIP_UI, true)

    fun timer(sec: Int, label: String) = Intent(AlarmClock.ACTION_SET_TIMER)
        .putExtra(AlarmClock.EXTRA_LENGTH, sec).putExtra(AlarmClock.EXTRA_MESSAGE, label)
        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)

    fun media(c: Context, key: Int) {
        val am = c.getSystemService(AudioManager::class.java)
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, key))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, key))
    }

    /** Returns (displayName, number) of the first contact matching [name]. */
    fun findContact(c: Context, name: String): Pair<String, String>? {
        if (ContextCompat.checkSelfPermission(c, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val P = ContactsContract.CommonDataKinds.Phone
        c.contentResolver.query(
            P.CONTENT_URI, arrayOf(P.DISPLAY_NAME, P.NUMBER),
            "${P.DISPLAY_NAME} LIKE ?", arrayOf("%$name%"), null
        )?.use { if (it.moveToFirst()) return it.getString(0) to it.getString(1) }
        return null
    }
}
