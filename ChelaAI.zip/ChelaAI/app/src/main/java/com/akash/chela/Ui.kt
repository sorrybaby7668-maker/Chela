package com.akash.chela

import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

val Bg = Color(0xFF02050C)
val Navy = Color(0xFF071427)
val Neon = Color(0xFF00E5FF)
val Blue = Color(0xFF2979FF)
val Panel = Color(0xFF0A1B33)
val Dim = Color(0xFF7FA6C9)

class Hooks(val wake: (Boolean) -> Unit, val battery: () -> Unit, val overlay: () -> Unit)

@Composable
fun ChelaTheme(content: @Composable () -> Unit) = MaterialTheme(
    colorScheme = darkColorScheme(primary = Neon, secondary = Blue, background = Bg, surface = Panel, onSurface = Color.White, onPrimary = Bg),
    content = content
)

private val Card = RoundedCornerShape(16.dp)
fun Modifier.neon(): Modifier = this.background(Panel.copy(alpha = 0.75f), Card).border(1.dp, Neon.copy(alpha = 0.35f), Card)

@Composable
fun ChelaRoot(vm: ChelaViewModel, hooks: Hooks) {
    var tab by remember { mutableIntStateOf(0) }
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Bg, Navy, Bg))).systemBarsPadding()) {
        Column(Modifier.fillMaxSize()) {
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Home(vm)
                    1 -> Chat(vm)
                    2 -> Tasks(vm.store)
                    else -> SettingsScreen(vm, hooks)
                }
            }
            NavBar(tab) { tab = it }
        }
    }
}

@Composable
fun NavBar(sel: Int, onSel: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Bg.copy(alpha = 0.9f)).padding(vertical = 8.dp)) {
        listOf("🏠" to "Home", "💬" to "Chat", "📝" to "Tasks", "⚙" to "Settings").forEachIndexed { i, (ic, l) ->
            Column(Modifier.weight(1f).clickable { onSel(i) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(ic, fontSize = 20.sp)
                Text(l, color = if (i == sel) Neon else Dim, fontSize = 11.sp)
            }
        }
    }
}

/** Animated glowing JARVIS-style core. Colour/speed change with the assistant state. */
@Composable
fun JarvisOrb(state: OrbState, diameter: Dp) {
    val t = rememberInfiniteTransition(label = "orb")
    val fast = state != OrbState.IDLE
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(if (fast) 3500 else 12000, easing = LinearEasing)), label = "s1")
    val spin2 by t.animateFloat(360f, 0f, infiniteRepeatable(tween(if (fast) 5000 else 18000, easing = LinearEasing)), label = "s2")
    val pulse by t.animateFloat(
        0.92f, 1.08f,
        infiniteRepeatable(tween(if (state == OrbState.LISTENING) 500 else 1600, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p"
    )
    val color = when (state) {
        OrbState.IDLE -> Neon
        OrbState.LISTENING -> Color(0xFF00FFC6)
        OrbState.THINKING -> Color(0xFF7C4DFF)
        OrbState.SPEAKING -> Color(0xFF40C4FF)
    }
    Canvas(Modifier.size(diameter)) {
        val r = size.minDimension / 2f
        val c = center
        drawCircle(Brush.radialGradient(listOf(color.copy(alpha = 0.55f), color.copy(alpha = 0.12f), Color.Transparent), c, r * pulse), r * pulse, c)
        drawCircle(color.copy(alpha = 0.8f), r * 0.62f, c, style = Stroke(2.dp.toPx()))
        rotate(spin, c) {
            for (k in 0 until 3) drawArc(color, k * 120f, 70f, false, Offset(c.x - r * 0.8f, c.y - r * 0.8f), Size(r * 1.6f, r * 1.6f), style = Stroke(5.dp.toPx(), cap = StrokeCap.Round))
        }
        rotate(spin2, c) {
            drawCircle(Blue, r * 0.9f, c, style = Stroke(2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(6f, 12f))))
        }
        drawCircle(Brush.radialGradient(listOf(Color.White.copy(alpha = 0.95f), color, Color.Transparent), c, r * 0.35f * pulse), r * 0.35f * pulse, c)
    }
}

private val QUICK = listOf(
    Triple("▶", "YouTube", "youtube kholo"), Triple("💬", "WhatsApp", "whatsapp kholo"), Triple("📷", "Camera", "camera kholo"),
    Triple("🧮", "Calculator", "calculator kholo"), Triple("⚙", "Settings", "settings kholo"), Triple("🌐", "Chrome", "chrome kholo")
)

@Composable
fun Home(vm: ChelaViewModel) {
    val orb by Chela.orb.collectAsState()
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(1000) } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("C H E L A   A I", color = Neon, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text("Welcome back, Sir Akash", color = Dim, fontSize = 13.sp)
        Spacer(Modifier.height(10.dp))
        Box(Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { vm.mic() }) { JarvisOrb(orb, 230.dp) }
        Text(
            when (orb) {
                OrbState.IDLE -> "Tap the core or say “Hello CHELA”"
                OrbState.LISTENING -> "Listening… बोलिए सर"
                OrbState.THINKING -> "Thinking…"
                OrbState.SPEAKING -> "Speaking…"
            }, color = Neon, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        if (vm.partial.value.isNotEmpty()) Text(vm.partial.value, color = Color.White, fontSize = 14.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(10.dp))
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { vm.setVoice(!vm.voiceOn.value) }) { Text(if (vm.voiceOn.value) "🔊 Voice ON" else "🔇 Voice OFF", color = Neon) }
            Button(onClick = { vm.mic() }, colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Bg)) { Text("🎤  Speak", fontWeight = FontWeight.Bold) }
            OutlinedButton(onClick = { vm.conv.value = !vm.conv.value; if (vm.conv.value) vm.mic() }) { Text(if (vm.conv.value) "♾ Talk ON" else "♾ Talk", color = Neon) }
        }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f).neon().padding(14.dp)) {
                Text(SimpleDateFormat("hh:mm:ss a", Locale.ENGLISH).format(now), color = Neon, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(SimpleDateFormat("EEE, d MMM yyyy", Locale.ENGLISH).format(now), color = Dim, fontSize = 12.sp)
            }
            Column(Modifier.weight(1f).neon().clickable { vm.refreshWeather() }.padding(14.dp)) {
                Text("🌤 Weather", color = Neon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Text(vm.weather.value, color = Color.White, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(14.dp))
        QUICK.chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { (ic, label, cmd) ->
                    Column(Modifier.weight(1f).neon().clickable { vm.send(cmd) }.padding(vertical = 14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(ic, fontSize = 24.sp); Text(label, color = Dim, fontSize = 12.sp)
                    }
                }
            }
            Spacer(Modifier.height(10.dp))
        }
    }
}

@Composable
fun Chat(vm: ChelaViewModel) {
    val rev by vm.store.rev.collectAsState()
    val orb by Chela.orb.collectAsState()
    val msgs = remember(rev) { vm.store.history() }
    var input by remember { mutableStateOf("") }
    val ls = rememberLazyListState()
    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) ls.animateScrollToItem(msgs.lastIndex) }
    Column(Modifier.fillMaxSize().imePadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            JarvisOrb(orb, 44.dp)
            Text("  CHELA CHAT", color = Neon, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            TextButton(onClick = { vm.store.clearHistory() }) { Text("Clear", color = Dim) }
        }
        LazyColumn(Modifier.weight(1f).padding(horizontal = 12.dp), state = ls, verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(msgs) { m ->
                val me = m.role == "user"
                Row(Modifier.fillMaxWidth(), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
                    Text(
                        m.text, color = Color.White,
                        modifier = Modifier.widthIn(max = 290.dp)
                            .background(if (me) Blue.copy(alpha = 0.35f) else Panel, RoundedCornerShape(14.dp))
                            .border(1.dp, (if (me) Blue else Neon).copy(alpha = 0.4f), RoundedCornerShape(14.dp)).padding(10.dp)
                    )
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f), placeholder = { Text("Sir, yahan likhiye…", color = Dim) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon, unfocusedBorderColor = Neon.copy(alpha = 0.4f), cursorColor = Neon)
            )
            Button(onClick = { if (input.isNotBlank()) { vm.send(input.trim()); input = "" } }, colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Bg)) { Text("➤") }
            Button(onClick = { vm.mic() }, colors = ButtonDefaults.buttonColors(containerColor = Blue)) { Text("🎤") }
        }
    }
}

@Composable
fun Tasks(store: Store) {
    val rev by store.rev.collectAsState()
    val notes = remember(rev) { store.notes() }
    val todos = remember(rev) { store.todos() }
    var mode by remember { mutableIntStateOf(0) }
    var input by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("NOTES & TO-DO", color = Neon, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Notes", "To-do").forEachIndexed { i, l ->
                if (mode == i) Button(onClick = { mode = i }, colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Bg)) { Text(l) }
                else OutlinedButton(onClick = { mode = i }) { Text(l, color = Neon) }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            OutlinedTextField(
                input, { input = it }, Modifier.weight(1f), singleLine = true, placeholder = { Text(if (mode == 0) "New note" else "New task", color = Dim) },
                colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon, unfocusedBorderColor = Neon.copy(alpha = 0.4f), cursorColor = Neon)
            )
            Button(onClick = { if (input.isNotBlank()) { if (mode == 0) store.addNote(input.trim()) else store.addTodo(input.trim()); input = "" } },
                colors = ButtonDefaults.buttonColors(containerColor = Neon, contentColor = Bg)) { Text("Add") }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (mode == 0) itemsIndexed(notes) { i, n ->
                Row(Modifier.fillMaxWidth().neon().padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(n, color = Color.White, modifier = Modifier.weight(1f))
                    TextButton(onClick = { store.deleteNote(i) }) { Text("🗑") }
                }
            } else itemsIndexed(todos) { i, t ->
                Row(Modifier.fillMaxWidth().neon(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(t.done, { store.toggleTodo(i) }, colors = CheckboxDefaults.colors(checkedColor = Neon, checkmarkColor = Bg))
                    Text(t.text, color = if (t.done) Dim else Color.White, textDecoration = if (t.done) TextDecoration.LineThrough else TextDecoration.None, modifier = Modifier.weight(1f))
                    TextButton(onClick = { store.deleteTodo(i) }) { Text("🗑") }
                }
            }
        }
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().neon().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Color.White)
        Switch(checked, onChange, colors = SwitchDefaults.colors(checkedTrackColor = Neon, checkedThumbColor = Bg))
    }
}

@Composable
fun SettingsScreen(vm: ChelaViewModel, hooks: Hooks) {
    val s = vm.store
    var hindi by remember { mutableStateOf(s.hindi) }
    var wake by remember { mutableStateOf(s.wake) }
    var city by remember { mutableStateOf(s.city) }
    val rev by s.rev.collectAsState()
    val memory = remember(rev) { s.memory() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("SETTINGS", color = Neon, fontWeight = FontWeight.Bold, fontSize = 18.sp)
        SwitchRow("Voice replies", vm.voiceOn.value) { vm.setVoice(it) }
        SwitchRow("Hindi listening (off = English)", hindi) { hindi = it; s.hindi = it }
        SwitchRow("Wake word “Hello CHELA” (background mic)", wake) { wake = it; hooks.wake(it) }
        OutlinedTextField(
            city, { city = it; s.city = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Weather city", color = Dim) },
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Neon, unfocusedBorderColor = Neon.copy(alpha = 0.4f), cursorColor = Neon)
        )
        OutlinedButton(onClick = { vm.refreshWeather() }, Modifier.fillMaxWidth()) { Text("Refresh weather", color = Neon) }
        Text("Keep wake word alive", color = Neon, fontWeight = FontWeight.Bold)
        Text(
            "Samsung: Settings → Battery → Background usage limits → Never sleeping apps → add CHELA AI. " +
                "Also: App info → Battery → Unrestricted, and lock the app in Recents.", color = Dim, fontSize = 12.sp
        )
        OutlinedButton(onClick = hooks.battery, Modifier.fillMaxWidth()) { Text("Battery optimization settings", color = Neon) }
        OutlinedButton(onClick = hooks.overlay, Modifier.fillMaxWidth()) { Text("Allow “display over other apps” (hands-free app launch)", color = Neon) }
        Text("Remembered about you", color = Neon, fontWeight = FontWeight.Bold)
        if (memory.isEmpty()) Text("Say: “yaad rakho ki mujhe chai pasand hai”", color = Dim, fontSize = 12.sp)
        memory.forEach { Text("• $it", color = Color.White, fontSize = 13.sp) }
        if (memory.isNotEmpty()) TextButton(onClick = { s.clearMemory() }) { Text("Forget everything", color = Dim) }
    }
}
