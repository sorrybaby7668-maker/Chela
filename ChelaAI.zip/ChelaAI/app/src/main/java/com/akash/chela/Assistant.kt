package com.akash.chela

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.view.KeyEvent
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object Wake {
    const val GREETING = "जी सर, मैं आपकी क्या मदद कर सकती हूँ?"
    private val hello = listOf("hello", "hallo", "helo", "hullo", "हेलो", "हैलो", "हलो")
    private val chela = listOf("chela", "chella", "shela", "chaila", "cheila", "चेला", "छेला", "चैला", "शेला", "चेल")
    fun isWake(t: String): Boolean { val l = t.lowercase(); return hello.any { l.contains(it) } && chela.any { l.contains(it) } }
    fun rest(t: String): String = Regex("(?i)^.*?(" + chela.joinToString("|") + ")\\s*").replace(t, "").trim()
}

/** Understands Hindi/English commands, runs phone actions, and falls back to the AI backend. */
class Assistant(private val app: Application, private val store: Store) {

    sealed class Pending {
        object NoteText : Pending()
        object TodoText : Pending()
        object CallName : Pending()
        data class WaContact(val text: String?) : Pending()
        data class WaText(val name: String, val number: String) : Pending()
        data class WaConfirm(val name: String, val number: String, val text: String) : Pending()
        data class CallConfirm(val name: String, val number: String) : Pending()
    }

    var pending: Pending? = null
        private set

    private val YES = setOf("haan", "han", "ha", "haa", "हाँ", "हां", "हा", "yes", "yeah", "yep", "ok", "okay", "theek", "ठीक", "जी", "ji", "confirm", "sure", "kardo", "bhejdo")
    private val CANCEL = setOf("cancel", "nahi", "nahin", "no", "नहीं", "नही", "रद्द", "chodo", "छोड़ो", "mat", "मत", "stop")
    private val FILL = setOf("banao", "bana", "do", "likho", "likh", "lo", "karo", "kar", "create", "add", "ki", "ke", "that", "jodo", "mein", "me", "to", "list", "a", "new", "in", "please",
        "बनाओ", "बना", "दो", "लिखो", "लिख", "लो", "करो", "कर", "कि", "जोड़ो", "में", "मे", "लिस्ट", "को", "ek", "एक")
    private val WA_FILL = setOf("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "व्हाट्सअप", "par", "pe", "पर", "message", "msg", "मैसेज", "bhejo", "भेजो", "bhej", "भेज",
        "send", "ko", "को", "to", "karo", "करो", "kar", "कर", "ek", "एक", "a", "mujhe", "please", "sir", "सर", "ka", "ki")
    private val CALL_FILL = setOf("call", "कॉल", "phone", "फोन", "dial", "डायल", "karo", "करो", "kar", "कर", "ko", "को", "lagao", "लगाओ", "milao", "मिलाओ", "to", "please", "make", "a", "sir", "सर")

    private fun tokens(t: String) = t.split(Regex("[\\s,.!?।:;]+")).filter { it.isNotEmpty() }
    private fun isYes(t: String) = tokens(t).any { it in YES } || listOf("kar do", "कर दो", "bhej do", "भेज दो").any { t.contains(it) }
    private fun clean(s: String) = s.lowercase().trim(':', ',', '.')

    /** Text after the first keyword, minus filler words. */
    private fun after(raw: String, keys: Set<String>): String {
        val tk = raw.split(Regex("\\s+")).filter { it.isNotBlank() }
        val idx = tk.indexOfFirst { clean(it) in keys }
        if (idx < 0) return ""
        return tk.drop(idx + 1).dropWhile { clean(it) in FILL }.dropLastWhile { clean(it) in FILL }.joinToString(" ")
    }

    private fun strip(raw: String, words: Set<String>) =
        raw.split(Regex("\\s+")).filter { clean(it) !in words }.joinToString(" ").trim()

    /** Stores both sides of the conversation and returns CHELA's reply. */
    suspend fun converse(text: String): String {
        store.addMsg(Msg("user", text))
        val r = try { handle(text) } catch (e: Exception) { "सर, कुछ गड़बड़ हो गई। फिर से कहिए।" }
        store.addMsg(Msg("assistant", r))
        return r
    }

    suspend fun handle(raw: String): String {
        val text = raw.trim()
        if (text.isEmpty()) return "जी सर?"
        pending?.let { return resolve(it, text, text.lowercase(Locale.ROOT)) }
        return route(text.replace(Regex("(?i)to do"), "todo"), text.lowercase(Locale.ROOT).replace("to do", "todo"))
    }

    // ---------- multi-step flows (always ask before call / WhatsApp) ----------
    private suspend fun resolve(p: Pending, raw: String, t: String): String {
        val w = tokens(t)
        if (w.size <= 3 && w.any { it in CANCEL }) { pending = null; return "ठीक है सर, रद्द कर दिया।" }
        pending = null
        return when (p) {
            Pending.NoteText -> { store.addNote(raw); "ठीक है सर, नोट सेव कर दिया।" }
            Pending.TodoText -> { store.addTodo(raw); "ठीक है सर, टू-डू में जोड़ दिया।" }
            Pending.CallName -> startCall(raw)
            is Pending.WaContact -> startWa(raw, p.text)
            is Pending.WaText -> {
                pending = Pending.WaConfirm(p.name, p.number, raw)
                "सर, ${p.name} को यह मैसेज तैयार करूँ: $raw। हाँ बोलिए तो WhatsApp में खोल दूँगी, भेजना आपके हाथ में रहेगा।"
            }
            is Pending.WaConfirm ->
                if (isYes(t)) { Chela.launch(Actions.waMessage(p.number, p.text)); "सर, मैसेज WhatsApp में तैयार है। भेजने के लिए सेंड बटन आप दबाइए।" }
                else "ठीक है सर, मैसेज नहीं भेजा।"
            is Pending.CallConfirm -> if (isYes(t)) doCall(p) else "ठीक है सर, कॉल नहीं लगाई।"
        }
    }

    private fun startWa(raw: String, preText: String?): String {
        val tk = raw.split(Regex("\\s+")).filter { it.isNotBlank() }
        val sep = tk.indexOfFirst { clean(it) in setOf("ki", "कि", "that", "saying", "likho", "लिखो") }
        var text = preText.orEmpty()
        val nameTokens = if (sep >= 0) { text = tk.drop(sep + 1).joinToString(" "); tk.take(sep) } else tk
        val name = nameTokens.filter { clean(it) !in WA_FILL }.joinToString(" ")
        if (name.isBlank()) { pending = Pending.WaContact(text.ifBlank { null }); return "सर, किस कॉन्टैक्ट को मैसेज भेजना है?" }
        val digits = name.filter { it.isDigit() }
        val c = if (digits.length >= 10) name to digits else Actions.findContact(app, name)
            ?: return "सर, मुझे \"$name\" नाम का कॉन्टैक्ट नहीं मिला। कॉन्टैक्ट्स की अनुमति और नाम (अंग्रेज़ी में) जाँच लीजिए।"
        return if (text.isBlank()) {
            pending = Pending.WaText(c.first, c.second); "ठीक है सर, ${c.first} को क्या मैसेज भेजना है?"
        } else {
            pending = Pending.WaConfirm(c.first, c.second, text); "सर, ${c.first} को मैसेज: $text। WhatsApp में तैयार करूँ? हाँ बोलिए।"
        }
    }

    private fun startCall(raw: String): String {
        val name = strip(raw, CALL_FILL)
        if (name.isBlank()) { pending = Pending.CallName; return "सर, किसे कॉल करूँ?" }
        val digits = name.filter { it.isDigit() }
        val c = (if (digits.length >= 7) name to digits else Actions.findContact(app, name))
            ?: return "सर, \"$name\" नाम का कॉन्टैक्ट नहीं मिला।"
        pending = Pending.CallConfirm(c.first, c.second)
        return "सर, ${c.first} को कॉल लगाऊँ? हाँ या ना बोलिए।"
    }

    private fun doCall(p: Pending.CallConfirm): String {
        val ok = ContextCompat.checkSelfPermission(app, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        Chela.launch(if (ok) Actions.call(p.number) else Actions.dial(p.number))
        return if (ok) "ठीक है सर, ${p.name} को कॉल लगा रही हूँ।" else "सर, कॉल की अनुमति नहीं है, इसलिए डायलर खोल रही हूँ।"
    }

    // ---------- command routing ----------
    private suspend fun route(raw: String, t: String): String {
        val w = tokens(t)
        fun has(vararg k: String) = k.any { if (' ' in it) t.contains(it) else it in w }
        val open = has("open", "kholo", "khol", "खोलो", "खोल", "start", "chalu", "चालू", "launch")

        if (Wake.isWake(t)) { val r = Wake.rest(raw); return if (r.length > 2) route(r, r.lowercase()) else Wake.GREETING }

        Regex("(?i)(remember that|remember|yaad rakho ki|yaad rakho|याद रखो कि|याद रखो)\\s*(.*)").find(raw)?.let {
            val fact = it.groupValues[2].trim()
            if (fact.isNotEmpty()) { store.remember(fact); return "ठीक है सर, मैं याद रखूँगी।" }
        }

        if (has("what time", "kitne baje", "कितने बजे", "time kya", "samay kya", "समय क्या", "टाइम क्या", "current time", "the time", "time batao", "टाइम बताओ", "समय बताओ"))
            return "सर, अभी समय ${SimpleDateFormat("h:mm a", Locale.ENGLISH).format(Date())} है।"
        if (has("date", "tarikh", "तारीख", "तारीख़", "aaj kya din", "आज कौन सा दिन", "what day"))
            return "सर, आज ${SimpleDateFormat("EEEE, d MMMM yyyy", Locale("hi", "IN")).format(Date())} है।"

        if (has("weather", "mausam", "मौसम")) {
            val city = Regex("(?:in|of|at)\\s+([a-z ]+?)\\s*$").find(t)?.groupValues?.get(1)
                ?: Regex("([a-z]+)\\s+(?:ka|ki)\\s+(?:mausam|weather)").find(t)?.groupValues?.get(1)
                ?: store.city
            return Net.weather(city.replaceFirstChar { it.uppercase() })
        }

        // apps
        if (has("calculator", "कैलकुलेटर", "calc") && open) { Chela.launch(Actions.calculator()); return "कैलकुलेटर खोल रही हूँ, सर।" }
        if (has("youtube", "यूट्यूब")) {
            val q = strip(raw, setOf("youtube", "यूट्यूब", "par", "pe", "on", "पर", "search", "play", "karo", "chalao", "चलाओ", "करो", "open", "kholo", "खोलो", "dhundo", "सर्च", "me", "mein", "में", "to"))
            Chela.launch(Actions.youtube(app, q))
            return if (q.isBlank()) "यूट्यूब खोल रही हूँ, सर।" else "यूट्यूब पर \"$q\" खोज रही हूँ, सर।"
        }
        if (has("camera", "कैमरा")) { Chela.launch(Actions.camera()); return "कैमरा खोल रही हूँ, सर।" }
        if (has("settings", "setting", "सेटिंग", "सेटिंग्स") && open) { Chela.launch(Actions.settings()); return "सेटिंग्स खोल रही हूँ, सर।" }
        if (has("chrome", "क्रोम")) { Chela.launch(Actions.chrome(app)); return "क्रोम खोल रही हूँ, सर।" }

        // alarm / reminder / timer
        if (has("alarm", "अलार्म", "remind", "reminder", "रिमाइंडर", "timer", "टाइमर", "yaad dilao", "याद दिलाओ"))
            return alarmOrReminder(raw, t, w, has("remind", "reminder", "रिमाइंडर", "yaad dilao", "याद दिलाओ"))

        // WhatsApp (never auto-sends)
        if (has("whatsapp", "व्हाट्सएप", "व्हाट्सऐप", "वॉट्सऐप", "व्हाट्सअप")) {
            if (!has("message", "msg", "मैसेज", "bhejo", "भेजो", "send", "bhej", "भेज")) {
                Chela.launch(Actions.whatsapp(app)); return "WhatsApp खोल रही हूँ, सर।"
            }
            return startWa(raw, null)
        }

        if (has("call", "कॉल", "phone", "फोन", "dial", "डायल")) return startCall(raw)

        // notes
        if (has("note", "notes", "नोट")) {
            if (has("show", "read", "list", "dikhao", "padho", "sunao", "सुनाओ", "दिखाओ", "पढ़ो", "mere"))
                return store.notes().takeLast(5).let { n -> if (n.isEmpty()) "सर, कोई नोट नहीं है।" else "सर, आपके नोट: " + n.joinToString("। ") }
            val c = after(raw, setOf("note", "notes", "नोट"))
            if (c.isBlank()) { pending = Pending.NoteText; return "सर, नोट में क्या लिखना है?" }
            store.addNote(c); return "ठीक है सर, नोट सेव कर दिया।"
        }

        // to-do
        if (has("todo", "to-do", "task", "tasks", "टास्क", "टूडू", "टू-डू")) {
            if (has("show", "read", "list", "dikhao", "padho", "sunao", "सुनाओ", "दिखाओ", "पढ़ो", "pending", "kya"))
                return store.todos().filter { !it.done }.let { l -> if (l.isEmpty()) "सर, कोई काम बाकी नहीं है।" else "सर, बाकी काम: " + l.joinToString("। ") { it.text } }
            val c = after(raw, setOf("todo", "to-do", "task", "tasks", "टास्क", "टूडू", "टू-डू"))
            if (c.isBlank()) { pending = Pending.TodoText; return "सर, टू-डू में क्या जोड़ूँ?" }
            store.addTodo(c); return "ठीक है सर, टू-डू में जोड़ दिया।"
        }

        // music controls
        if (has("music", "song", "gaana", "gana", "गाना", "गाने", "म्यूजिक", "म्यूज़िक", "spotify")) {
            val key = when {
                has("pause", "roko", "रोको", "stop", "बंद", "band") -> KeyEvent.KEYCODE_MEDIA_PAUSE to "म्यूजिक पॉज़ कर दिया।"
                has("next", "agla", "अगला", "skip") -> KeyEvent.KEYCODE_MEDIA_NEXT to "अगला गाना चला रही हूँ।"
                has("previous", "pichla", "पिछला", "back") -> KeyEvent.KEYCODE_MEDIA_PREVIOUS to "पिछला गाना चला रही हूँ।"
                has("play", "chalao", "चलाओ", "start", "resume") -> KeyEvent.KEYCODE_MEDIA_PLAY to "म्यूजिक चला रही हूँ।"
                else -> null
            }
            if (key != null) { Actions.media(app, key.first); return "ठीक है सर, ${key.second}" }
        }

        // calculator maths
        if (t.any { it.isDigit() }) {
            val cue = has("calculate", "kitna", "कितना", "कैलकुलेट", "plus", "minus", "guna", "गुणा", "divided", "जोड़", "घटा", "into", "times", "equals", "क्या होगा") ||
                Regex("^[\\d\\s+\\-*/x×÷().]+$").matches(t)
            if (cue) evalMath(t)?.let { return "सर, जवाब है $it।" }
        }

        // Google search
        if (has("search", "google", "dhundo", "khojo", "ढूँढो", "खोजो", "सर्च", "गूगल", "dhoondo")) {
            val q = strip(raw, setOf("search", "google", "karo", "kar", "करो", "सर्च", "गूगल", "dhundo", "khojo", "dhoondo", "ढूँढो", "खोजो", "for", "on", "par", "पर", "me", "mein", "में", "it", "to"))
            if (q.isBlank()) return "सर, क्या सर्च करूँ?"
            Chela.launch(Actions.google(q)); return "ठीक है सर, \"$q\" गूगल पर सर्च कर रही हूँ।"
        }

        return Net.ask(store.history(), store.memory())
    }

    private fun alarmOrReminder(raw: String, t: String, w: List<String>, rem: Boolean): String {
        val label = if (rem) after(raw, setOf("remind", "reminder", "रिमाइंडर")).ifBlank { "Reminder" }.take(60) else "CHELA"
        val d = Regex("(\\d+)\\s*(minutes?|mins?|मिनट|hours?|ghante|ghanta|घंटे|घंटा|seconds?|secs?|सेकंड)").find(t)
        if (d != null) {
            val n = d.groupValues[1].toInt(); val u = d.groupValues[2]
            val sec = n * when {
                u.startsWith("min") || u == "मिनट" -> 60
                u.startsWith("hour") || u.startsWith("ghant") || u.startsWith("घंट") -> 3600
                else -> 1
            }
            Chela.launch(Actions.timer(sec, label))
            return "ठीक है सर, $n $u बाद के लिए ${if (rem) "रिमाइंडर" else "टाइमर"} सेट कर दिया।"
        }
        val m = Regex("(\\d{1,2})(?::(\\d{2}))?").find(t) ?: return "सर, किस समय के लिए सेट करूँ? जैसे \"सुबह 6 बजे अलार्म\"।"
        var h = m.groupValues[1].toInt()
        val min = m.groupValues[2].ifEmpty { "0" }.toInt()
        val pm = w.any { it in setOf("pm", "शाम", "raat", "रात", "dopahar", "दोपहर", "evening", "night") } || Regex("\\d\\s*p\\.?m").containsMatchIn(t)
        val am = w.any { it in setOf("am", "subah", "सुबह", "morning") } || Regex("\\d\\s*a\\.?m").containsMatchIn(t)
        if (pm && h < 12) h += 12 else if (am && h == 12) h = 0
        if (h > 23 || min > 59) return "सर, समय सही नहीं लगा।"
        Chela.launch(Actions.alarm(h, min, label))
        return "ठीक है सर, ${"%d:%02d".format(h, min)} बजे के लिए ${if (rem) "रिमाइंडर" else "अलार्म"} सेट कर दिया।"
    }

    // ---------- tiny calculator ----------
    private fun evalMath(t: String): String? {
        val s = t.replace("plus", "+").replace("minus", "-").replace("times", "*").replace("into", "*")
            .replace("guna", "*").replace("गुणा", "*").replace("divided by", "/").replace("bhaag", "/")
            .replace("भाग", "/").replace("x", "*").replace("×", "*").replace("÷", "/")
            .filter { it.isDigit() || it in ".+-*/()" }
        if (s.none { it in "+-*/" }) return null
        return try {
            val v = Parser(s).parse()
            if (v.isNaN() || v.isInfinite()) null
            else if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString() else "%.4f".format(Locale.ENGLISH, v).trimEnd('0').trimEnd('.')
        } catch (e: Exception) { null }
    }

    private class Parser(val s: String) {
        var i = 0
        fun parse(): Double { val v = expr(); if (i < s.length) throw IllegalStateException(); return v }
        fun expr(): Double {
            var v = term()
            while (i < s.length && (s[i] == '+' || s[i] == '-')) { val o = s[i++]; val r = term(); v = if (o == '+') v + r else v - r }
            return v
        }
        fun term(): Double {
            var v = factor()
            while (i < s.length && (s[i] == '*' || s[i] == '/')) { val o = s[i++]; val r = factor(); v = if (o == '*') v * r else v / r }
            return v
        }
        fun factor(): Double {
            if (s[i] == '-') { i++; return -factor() }
            if (s[i] == '(') { i++; val v = expr(); i++; return v }
            val st = i
            while (i < s.length && (s[i].isDigit() || s[i] == '.')) i++
            return s.substring(st, i).toDouble()
        }
    }
}
