package com.akash.chela

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.provider.Settings
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.flow.MutableStateFlow

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

class ChelaApp : Application() {
    override fun onCreate() { super.onCreate(); Chela.init(this) }
}

/** Process-wide singletons shared by the UI and the background wake-word service. */
object Chela {
    lateinit var app: Application
    lateinit var store: Store
    lateinit var assistant: Assistant
    val orb = MutableStateFlow(OrbState.IDLE)
    @Volatile var foreground = false

    fun init(a: Application) { app = a; store = Store(a); assistant = Assistant(a, store) }

    /**
     * Android 14 blocks activity launches from the background. We launch directly when the app is visible
     * (or has the "display over other apps" permission); otherwise we post a tap-to-continue notification.
     */
    fun launch(i: Intent) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        if (foreground || Settings.canDrawOverlays(app)) {
            try { app.startActivity(i) } catch (e: Exception) { }
            return
        }
        val nm = app.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("chela_actions", "CHELA actions", NotificationManager.IMPORTANCE_HIGH))
        val pi = PendingIntent.getActivity(
            app, (System.currentTimeMillis() % 100000).toInt(), i,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        nm.notify(42, NotificationCompat.Builder(app, "chela_actions")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("CHELA AI").setContentText("Sir, tap to continue")
            .setContentIntent(pi).setFullScreenIntent(pi, true).setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH).build())
    }
}
