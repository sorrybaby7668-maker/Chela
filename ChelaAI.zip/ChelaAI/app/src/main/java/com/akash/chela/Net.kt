package com.akash.chela

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.math.roundToInt

object Net {
    private val http = OkHttpClient.Builder().callTimeout(45, TimeUnit.SECONDS).build()
    private val JSON = "application/json".toMediaType()

    /** Talks ONLY to your own backend. The Anthropic API key lives on the server, never in the APK. */
    suspend fun ask(history: List<Msg>, memory: List<String>): String = withContext(Dispatchers.IO) {
        if (BuildConfig.BACKEND_URL.isBlank())
            return@withContext "सर, बैकएंड का URL सेट नहीं है। local.properties में CHELA_BACKEND_URL डालिए।"
        try {
            val msgs = JSONArray()
            history.takeLast(12).forEach {
                msgs.put(JSONObject().put("role", if (it.role == "user") "user" else "assistant").put("content", it.text))
            }
            val body = JSONObject().put("messages", msgs).put("memory", JSONArray(memory)).toString()
            val req = Request.Builder()
                .url(BuildConfig.BACKEND_URL.trimEnd('/') + "/chat")
                .header("X-Chela-Token", BuildConfig.APP_TOKEN)
                .post(body.toRequestBody(JSON)).build()
            http.newCall(req).execute().use { r ->
                val s = r.body?.string().orEmpty()
                if (!r.isSuccessful) "सर, सर्वर से जवाब नहीं मिला (${r.code})।"
                else JSONObject(s).optString("reply", "सर, जवाब खाली आया।")
            }
        } catch (e: Exception) {
            "सर, इंटरनेट या सर्वर में समस्या है।"
        }
    }

    private fun get(url: String): String =
        http.newCall(Request.Builder().url(url).build()).execute().use { it.body?.string().orEmpty() }

    /** Free Open-Meteo API (no key needed). */
    suspend fun weather(city: String): String = withContext(Dispatchers.IO) {
        try {
            val g = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?count=1&name=" + URLEncoder.encode(city, "UTF-8")))
            val r = g.optJSONArray("results")?.getJSONObject(0) ?: return@withContext "सर, $city शहर नहीं मिला।"
            val w = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=${r.getDouble("latitude")}&longitude=${r.getDouble("longitude")}&current=temperature_2m,relative_humidity_2m,weather_code"))
            val c = w.getJSONObject("current")
            "$city में अभी तापमान ${c.getDouble("temperature_2m").roundToInt()} डिग्री है, ${desc(c.getInt("weather_code"))}, और नमी ${c.getInt("relative_humidity_2m")} प्रतिशत है।"
        } catch (e: Exception) {
            "सर, मौसम की जानकारी नहीं मिल पाई।"
        }
    }

    private fun desc(c: Int) = when (c) {
        0 -> "आसमान साफ़ है"
        1, 2, 3 -> "बादल छाए हैं"
        45, 48 -> "कोहरा है"
        in 51..57 -> "हल्की बूँदाबाँदी है"
        in 61..67, in 80..82 -> "बारिश हो रही है"
        in 71..77 -> "बर्फ़बारी है"
        in 95..99 -> "आँधी-तूफ़ान है"
        else -> "मौसम मिला-जुला है"
    }
}
