package com.akash.chela

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {
    private val vm: ChelaViewModel by viewModels()

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        if (Chela.store.wake && micOk()) startWake()
    }

    private fun micOk() = ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val need = buildList {
            add(Manifest.permission.RECORD_AUDIO); add(Manifest.permission.CALL_PHONE); add(Manifest.permission.READ_CONTACTS)
            if (Build.VERSION.SDK_INT >= 33) add(Manifest.permission.POST_NOTIFICATIONS)
        }.filter { ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) perms.launch(need.toTypedArray())

        val hooks = Hooks(
            wake = ::toggleWake,
            battery = { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) },
            overlay = { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        )
        setContent { ChelaTheme { ChelaRoot(vm, hooks) } }
        if (Chela.store.wake && micOk() && !WakeService.running) startWake()
    }

    private fun toggleWake(on: Boolean) {
        Chela.store.wake = on
        if (!on) { stopService(Intent(this, WakeService::class.java)); return }
        if (micOk()) startWake() else perms.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
    }

    // Android 14: a microphone foreground service may only be started while the app is visible.
    private fun startWake() = ContextCompat.startForegroundService(this, Intent(this, WakeService::class.java))

    override fun onStart() { super.onStart(); Chela.foreground = true }
    override fun onStop() { Chela.foreground = false; super.onStop() }
}
