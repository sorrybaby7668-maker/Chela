// CHELA AI backend: keeps the Anthropic API key OFF the phone. Zero dependencies (Node 18+).
import http from "node:http";

const { ANTHROPIC_API_KEY, CHELA_APP_TOKEN, PORT = 8080, CHELA_MODEL = "claude-sonnet-5-5", ENABLE_SEARCH } = process.env;
if (!ANTHROPIC_API_KEY || !CHELA_APP_TOKEN) { console.error("Set ANTHROPIC_API_KEY and CHELA_APP_TOKEN"); process.exit(1); }

const SYSTEM = `You are CHELA AI, the friendly, intelligent female personal assistant of Akash. Always call him "Sir".
Reply in Hindi (Devanagari script) by default. If Sir speaks or writes in English, reply in English.
Your replies are spoken aloud: keep them short (1-3 sentences), natural, warm. No markdown, no emojis, no lists.
Use feminine grammar in Hindi (e.g. "kar sakti hoon"). Be honest if you are unsure.`;

const hits = new Map();
const limited = (ip) => { const now = Date.now(); const a = (hits.get(ip) || []).filter((t) => now - t < 60000); a.push(now); hits.set(ip, a); return a.length > 30; };

// Anthropic requires alternating roles starting with "user".
function clean(msgs) {
  const out = [];
  for (const m of msgs.slice(-12)) {
    const role = m.role === "user" ? "user" : "assistant";
    const content = String(m.content || "").slice(0, 2000);
    if (!content) continue;
    if (out.length === 0 && role !== "user") continue;
    if (out.at(-1)?.role === role) out.at(-1).content += "\n" + content; else out.push({ role, content });
  }
  return out;
}

http.createServer(async (req, res) => {
  const send = (c, o) => { res.writeHead(c, { "content-type": "application/json" }); res.end(JSON.stringify(o)); };
  if (req.url === "/health") return send(200, { ok: true });
  if (req.method !== "POST" || req.url !== "/chat") return send(404, { error: "not found" });
  if (req.headers["x-chela-token"] !== CHELA_APP_TOKEN) return send(401, { error: "unauthorized" });
  const ip = req.headers["x-forwarded-for"]?.split(",")[0] ?? req.socket.remoteAddress;
  if (limited(ip)) return send(429, { error: "slow down" });

  let body = "";
  for await (const c of req) { body += c; if (body.length > 50000) return send(413, { error: "too large" }); }
  try {
    const { messages = [], memory = [] } = JSON.parse(body);
    const msgs = clean(messages);
    if (!msgs.length) return send(400, { error: "no messages" });
    const system = SYSTEM + (memory.length ? "\nThings Sir asked you to remember:\n- " + memory.slice(-20).map(String).join("\n- ") : "");
    const payload = { model: CHELA_MODEL, max_tokens: 500, system, messages: msgs };
    if (ENABLE_SEARCH === "1") payload.tools = [{ type: "web_search_20250305", name: "web_search", max_uses: 3 }];
    const r = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": ANTHROPIC_API_KEY, "anthropic-version": "2023-06-01" },
      body: JSON.stringify(payload),
    });
    const j = await r.json();
    if (!r.ok) { console.error(j); return send(502, { error: "upstream" }); }
    send(200, { reply: j.content.filter((b) => b.type === "text").map((b) => b.text).join("").trim() });
  } catch (e) { console.error(e); send(500, { error: "server" }); }
}).listen(PORT, () => console.log("CHELA backend on :" + PORT));
