# CHELA AI — personal assistant for Akash (Galaxy A04s, Android 14)

Kotlin + Jetpack Compose. Hindi-first, JARVIS-style UI, wake word "Hello CHELA", secure backend.

## 1. Backend (keeps your API key off the phone)
```
cd server
export ANTHROPIC_API_KEY=sk-ant-...        # from console.anthropic.com
export CHELA_APP_TOKEN=$(openssl rand -hex 24)
# optional: ENABLE_SEARCH=1 (web search), CHELA_MODEL=...
node index.js
```
Deploy on Render / Railway / Fly / any VPS **with HTTPS** (the app blocks plain http). Test: `curl https://HOST/health`.

## 2. App
1. Copy `local.properties.example` → `local.properties`, set `sdk.dir`, `CHELA_BACKEND_URL`, `CHELA_APP_TOKEN` (same token as the server).
2. Open the `ChelaAI` folder in Android Studio (Koala+, JDK 17) → Sync → Run on the phone (USB debugging).
3. Allow Microphone, Contacts, Phone, Notifications when asked.
4. Install/enable **Google** app + **Speech Recognition & Synthesis** with Hindi voice data (Settings → General management → Text-to-speech → Google, download Hindi). Pick a female Hindi voice there if CHELA sounds male.

## 3. Always-on "Hello CHELA"
Settings tab → turn on Wake word (starts a microphone foreground service with a notification). Then:
- Samsung: Settings → Battery → Background usage limits → Never sleeping apps → add CHELA AI; App info → Battery → Unrestricted; lock app in Recents.
- Turn on "display over other apps" so CHELA can open apps while the screen app is in background (Android 14 otherwise only shows a tap-to-continue notification).
- Android 14 only lets a mic service start while the app is visible, so open the app once after every reboot.

## 4. Try these (Hindi or English)
`youtube kholo` · `youtube par arijit songs chalao` · `whatsapp kholo` · `Rahul ko whatsapp message bhejo ki kal milte hain` · `Mom ko call karo` · `google search best phones` · `alarm subah 6:30 baje` · `10 minute baad remind me chai` · `note likho: doodh lana` · `todo mein milk jodo` · `mere notes dikhao` · `mausam batao` / `weather in Mumbai` · `5 plus 7 guna 2` · `music pause / next` · `yaad rakho ki mujhe chai pasand hai` · any other question → AI.

## Safety design
- Calls and WhatsApp always ask "haan/nahi" first. WhatsApp opens the chat with text pre-filled; **you press Send** — CHELA never sends by itself.
- API key only on your server; app holds a revocable app token. `allowBackup=false`, HTTPS only, server rate-limits.

## Known limits
- Contact names are matched as typed in your contacts (English names work best by voice).
- Wake word uses Android's speech recognizer in a loop: uses battery and some phones beep on restart.
- Reminders use the Clock app (alarm/timer) so no exact-alarm permission is needed.
- No launcher icon included (default is used) — add one via Android Studio → New → Image Asset.
